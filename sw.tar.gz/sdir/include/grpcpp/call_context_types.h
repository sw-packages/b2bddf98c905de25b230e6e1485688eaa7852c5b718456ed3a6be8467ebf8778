// Copyright 2026 gRPC authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef GRPCPP_CALL_CONTEXT_TYPES_H
#define GRPCPP_CALL_CONTEXT_TYPES_H

#include <grpc/context_types.h>

namespace grpc {

// The types defined here may be passed to ClientContext::SetContext().
using TelemetryLabel = grpc_core::TelemetryLabel;

}  // namespace grpc

#endif  // GRPCPP_CALL_CONTEXT_TYPES_H
